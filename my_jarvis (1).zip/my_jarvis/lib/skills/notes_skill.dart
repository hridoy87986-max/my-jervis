import 'package:shared_preferences/shared_preferences.dart';
import '../core/skill.dart';

/// Simple notes: add, list, search. Stored on the phone.
class NotesSkill extends Skill {
  static const _prefsKey = 'jarvis_notes';

  @override
  String get name => 'notes';

  @override
  String get description =>
      'Add, list or search the user\'s notes. '
      'action "add" needs text; "search" needs query; "list" shows recent notes.';

  @override
  Map<String, dynamic> get inputSchema => {
        'type': 'object',
        'properties': {
          'action': {
            'type': 'string',
            'enum': ['add', 'list', 'search']
          },
          'text': {'type': 'string'},
          'query': {'type': 'string'},
        },
        'required': ['action'],
      };

  @override
  Future<String> run(Map<String, dynamic> args) async {
    final prefs = await SharedPreferences.getInstance();
    final notes = prefs.getStringList(_prefsKey) ?? <String>[];

    switch (args['action']) {
      case 'add':
        final stamp = DateTime.now().toIso8601String().substring(0, 16);
        notes.add('[$stamp] ${args['text']}');
        await prefs.setStringList(_prefsKey, notes);
        return 'Note saved.';
      case 'list':
        if (notes.isEmpty) return 'No notes yet.';
        return notes.reversed.take(10).join('\n');
      case 'search':
        final q = (args['query'] as String? ?? '').toLowerCase();
        final hits = notes.where((n) => n.toLowerCase().contains(q)).toList();
        return hits.isEmpty ? 'No matching notes.' : hits.join('\n');
      default:
        return 'Unknown action.';
    }
  }
}
