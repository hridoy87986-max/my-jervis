import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:flutter_timezone/flutter_timezone.dart';
import 'package:timezone/data/latest_all.dart' as tzdata;
import 'package:timezone/timezone.dart' as tz;
import '../core/skill.dart';

/// Schedules a local notification after N minutes.
class ReminderSkill extends Skill {
  final _plugin = FlutterLocalNotificationsPlugin();
  var _ready = false;

  Future<void> init() async {
    if (_ready) return;
    tzdata.initializeTimeZones();
    final localName = await FlutterTimezone.getLocalTimezone();
    tz.setLocalLocation(tz.getLocation(localName));

    await _plugin.initialize(const InitializationSettings(
      android: AndroidInitializationSettings('@mipmap/ic_launcher'),
      iOS: DarwinInitializationSettings(),
    ));
    await _plugin
        .resolvePlatformSpecificImplementation<
            AndroidFlutterLocalNotificationsPlugin>()
        ?.requestNotificationsPermission();
    _ready = true;
  }

  @override
  String get name => 'reminder';

  @override
  String get description =>
      'Set a reminder that shows a notification after a number of minutes.';

  @override
  Map<String, dynamic> get inputSchema => {
        'type': 'object',
        'properties': {
          'title': {'type': 'string', 'description': 'What to remind about'},
          'minutes_from_now': {'type': 'integer', 'minimum': 1},
        },
        'required': ['title', 'minutes_from_now'],
      };

  @override
  Future<String> run(Map<String, dynamic> args) async {
    await init();
    final minutes = (args['minutes_from_now'] as num).toInt();
    final title = args['title'] as String;
    final when = tz.TZDateTime.now(tz.local).add(Duration(minutes: minutes));

    await _plugin.zonedSchedule(
      when.millisecondsSinceEpoch ~/ 1000 % 2147483647,
      'Reminder',
      title,
      when,
      const NotificationDetails(
        android: AndroidNotificationDetails(
          'jarvis_reminders',
          'Reminders',
          importance: Importance.high,
          priority: Priority.high,
        ),
        iOS: DarwinNotificationDetails(),
      ),
      androidScheduleMode: AndroidScheduleMode.inexactAllowWhileIdle,
      uiLocalNotificationDateInterpretation:
          UILocalNotificationDateInterpretation.absoluteTime,
    );
    return 'Reminder set for $minutes minute(s) from now: $title';
  }
}
