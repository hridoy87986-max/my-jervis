import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import '../core/skill.dart';

/// Long-term key/value memory stored on the phone.
class MemorySkill extends Skill {
  static const _prefsKey = 'jarvis_memory';

  @override
  String get name => 'memory';

  @override
  String get description =>
      'Save or recall facts about the user (name, preferences, people). '
      'Use action "save" to store, "get" to read one key, "list" to read all.';

  @override
  Map<String, dynamic> get inputSchema => {
        'type': 'object',
        'properties': {
          'action': {
            'type': 'string',
            'enum': ['save', 'get', 'list']
          },
          'key': {'type': 'string'},
          'value': {'type': 'string'},
        },
        'required': ['action'],
      };

  Future<Map<String, dynamic>> _load() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(_prefsKey);
    return raw == null ? {} : jsonDecode(raw) as Map<String, dynamic>;
  }

  @override
  Future<String> run(Map<String, dynamic> args) async {
    final prefs = await SharedPreferences.getInstance();
    final data = await _load();
    switch (args['action']) {
      case 'save':
        data[args['key'] as String] = args['value'];
        await prefs.setString(_prefsKey, jsonEncode(data));
        return 'Saved ${args['key']}.';
      case 'get':
        return data[args['key']]?.toString() ?? 'Nothing saved for ${args['key']}.';
      case 'list':
        return data.isEmpty ? 'Memory is empty.' : jsonEncode(data);
      default:
        return 'Unknown action.';
    }
  }
}
