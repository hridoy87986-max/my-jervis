import 'package:flutter/material.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';

import 'core/brain.dart';
import 'core/on_device_llm.dart';
import 'core/skill_registry.dart';
import 'core/voice_service.dart';
import 'skills/memory_skill.dart';
import 'skills/notes_skill.dart';
import 'skills/reminder_skill.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const JarvisApp());
}

class JarvisApp extends StatelessWidget {
  const JarvisApp({super.key});

  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'My Jarvis',
        theme: ThemeData(
          colorSchemeSeed: Colors.indigo,
          useMaterial3: true,
          brightness: Brightness.dark,
        ),
        home: const ChatScreen(),
      );
}

class ChatScreen extends StatefulWidget {
  const ChatScreen({super.key});

  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  final _storage = const FlutterSecureStorage();
  final _registry = SkillRegistry();
  final _voice = VoiceService();
  final _llm = OnDeviceLlm();
  String? _status; // model download / loading message
  double? _progress;
  final _controller = TextEditingController();
  final _messages = <({bool fromUser, String text})>[];

  late Brain _brain;
  var _busy = false;

  @override
  void initState() {
    super.initState();
    _setup();
  }

  Future<void> _setup() async {
    // ---- Register skills here. Add new ones with one line. ----
    final reminder = ReminderSkill();
    await reminder.init();
    _registry
      ..register(MemorySkill())
      ..register(NotesSkill())
      ..register(reminder);

    await _voice.init();
    await _buildBrain();
    if (await _llm.isInstalled()) await _loadModel();
  }

  Future<void> _loadModel() async {
    setState(() => _status = 'Loading offline AI...');
    try {
      await _llm.load();
      setState(() => _status = null);
    } catch (e) {
      setState(() => _status = 'Could not load model: $e');
    }
    await _buildBrain();
  }

  Future<void> _downloadModel() async {
    setState(() {
      _status = 'Downloading offline AI (large file, use Wi-Fi)...';
      _progress = 0;
    });
    try {
      await _llm.install((p) => setState(() => _progress = p / 100));
      setState(() => _progress = null);
      await _loadModel();
    } catch (e) {
      setState(() {
        _progress = null;
        _status = 'Download failed: $e';
      });
    }
  }

  Future<void> _buildBrain() async {
    final key = await _storage.read(key: 'anthropic_key');
    final local = LocalBrain(_registry);
    _brain = HybridBrain(
      local: local,
      onDevice: OnDeviceBrain(llm: _llm, registry: _registry),
      cloud: (key == null || key.isEmpty)
          ? null
          : ClaudeBrain(apiKey: key, registry: _registry),
    );
    if (mounted) setState(() {});
  }

  Future<void> _send(String text) async {
    if (text.trim().isEmpty || _busy) return;
    _controller.clear();
    setState(() {
      _messages.add((fromUser: true, text: text));
      _busy = true;
    });
    final answer = await _brain.reply(text);
    setState(() {
      _messages.add((fromUser: false, text: answer));
      _busy = false;
    });
    await _voice.speak(answer);
  }

  Future<void> _toggleMic() async {
    if (_voice.isListening) {
      await _voice.stopListening();
    } else {
      await _voice.listen((text, isFinal) {
        _controller.text = text;
        if (isFinal) _send(text);
      });
    }
    setState(() {});
  }

  Future<void> _askApiKey() async {
    final field = TextEditingController();
    await showDialog<void>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Claude API key'),
        content: TextField(
          controller: field,
          obscureText: true,
          decoration: const InputDecoration(hintText: 'sk-ant-...'),
        ),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
          FilledButton(
            onPressed: () async {
              await _storage.write(key: 'anthropic_key', value: field.text.trim());
              await _buildBrain();
              if (ctx.mounted) Navigator.pop(ctx);
            },
            child: const Text('Save'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('My Jarvis'),
        actions: [
          IconButton(
              icon: const Icon(Icons.download),
              tooltip: 'Download offline AI',
              onPressed: _downloadModel),
          IconButton(icon: const Icon(Icons.key), onPressed: _askApiKey),
        ],
      ),
      body: Column(
        children: [
          Expanded(
            child: ListView.builder(
              padding: const EdgeInsets.all(12),
              itemCount: _messages.length,
              itemBuilder: (_, i) {
                final m = _messages[i];
                return Align(
                  alignment:
                      m.fromUser ? Alignment.centerRight : Alignment.centerLeft,
                  child: Container(
                    margin: const EdgeInsets.symmetric(vertical: 4),
                    padding: const EdgeInsets.all(12),
                    constraints: BoxConstraints(
                        maxWidth: MediaQuery.of(context).size.width * 0.8),
                    decoration: BoxDecoration(
                      color: m.fromUser
                          ? Theme.of(context).colorScheme.primaryContainer
                          : Theme.of(context).colorScheme.surfaceContainerHighest,
                      borderRadius: BorderRadius.circular(16),
                    ),
                    child: Text(m.text),
                  ),
                );
              },
            ),
          ),
          if (_status != null)
            Padding(
              padding: const EdgeInsets.all(8),
              child: Text(_status!, style: const TextStyle(fontSize: 12)),
            ),
          if (_progress != null) LinearProgressIndicator(value: _progress),
          if (_busy) const LinearProgressIndicator(),
          SafeArea(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(8, 4, 8, 8),
              child: Row(
                children: [
                  IconButton(
                    icon: Icon(_voice.isListening ? Icons.mic : Icons.mic_none),
                    onPressed: _toggleMic,
                  ),
                  Expanded(
                    child: TextField(
                      controller: _controller,
                      onSubmitted: _send,
                      decoration: const InputDecoration(
                        hintText: 'কিছু বলো বা লেখো...',
                        border: OutlineInputBorder(),
                      ),
                    ),
                  ),
                  IconButton(
                    icon: const Icon(Icons.send),
                    onPressed: () => _send(_controller.text),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
