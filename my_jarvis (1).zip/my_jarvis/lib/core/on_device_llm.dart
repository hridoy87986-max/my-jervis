import 'package:flutter_edge_ai/flutter_edge_ai.dart';
import 'package:flutter_edge_ai_litertlm/flutter_edge_ai_litertlm.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// Runs a small language model fully on the phone (no internet after the
/// one-time model download). Uses flutter_edge_ai + LiteRT-LM (.litertlm).
///
/// Fields are `dynamic` on purpose: the exact class names of the model/chat
/// objects are not needed, only the calls documented in the package README.
class OnDeviceLlm {
  static const _installedKey = 'ondevice_model_installed';

  dynamic _model;
  dynamic _chat;
  var _engineReady = false;
  var _firstTurn = true;

  bool get isLoaded => _chat != null;

  Future<void> _initEngine() async {
    if (_engineReady) return;
    await FlutterEdgeAi.initialize(inferenceEngines: [LiteRtLmEngine()]);
    _engineReady = true;
  }

  Future<bool> isInstalled() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getBool(_installedKey) ?? false;
  }

  /// One-time download (Gemma 4 E2B, a large file: use Wi-Fi).
  Future<void> install(void Function(double percent) onProgress) async {
    await _initEngine();
    await FlutterEdgeAi.installModelFromCatalog(
            LiteRtLmModels.gemma4E2bIt.generic)
        .withProgress((progress) => onProgress((progress as num).toDouble()))
        .install();
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(_installedKey, true);
  }

  /// Loads the installed model into memory and opens one chat.
  Future<void> load() async {
    await _initEngine();
    _model = await FlutterEdgeAi.getActiveModel(maxTokens: 4096);
    _chat = await _model.openChat();
    _firstTurn = true;
  }

  /// [instructions] are prepended to the first message only; the chat keeps
  /// history after that.
  Future<String> ask(String text, {required String instructions}) async {
    if (_chat == null) throw StateError('Model not loaded');
    final content = _firstTurn ? '$instructions\n\nUser: $text' : text;
    _firstTurn = false;

    await _chat.addQueryChunk(Message.text(text: content, isUser: true));
    final reply = StringBuffer();
    await for (final response in _chat.generateChatResponseAsync()) {
      if (response is TextResponse) reply.write(response.token);
    }
    return reply.toString().trim();
  }

  Future<void> close() async {
    await _model?.close();
    _model = null;
    _chat = null;
  }
}
