/// Every ability of the assistant is a Skill.
/// To add a new ability: extend this class, then register it in main.dart.
abstract class Skill {
  /// Unique snake_case name (the AI uses this to call the skill).
  String get name;

  /// Plain-English description so the AI knows WHEN to use the skill.
  String get description;

  /// JSON Schema describing the arguments.
  Map<String, dynamic> get inputSchema;

  /// Does the work and returns a text result for the AI.
  Future<String> run(Map<String, dynamic> args);

  /// Format expected by the Claude Messages API `tools` field.
  Map<String, dynamic> toClaudeTool() => {
        'name': name,
        'description': description,
        'input_schema': inputSchema,
      };
}
