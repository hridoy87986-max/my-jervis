import 'dart:convert';
import 'package:http/http.dart' as http;
import 'on_device_llm.dart';
import 'skill_registry.dart';

abstract class Brain {
  Future<String> reply(String userText);
}

const _system = '''
You are a personal AI assistant running inside a mobile app.
Reply in the same language the user writes in (Bengali, Hindi, English...).
Keep answers short; the user reads on a phone.
Use the available tools (memory, notes, reminders) whenever they help.
''';

/// Cloud brain: Claude API with tool use (skills are exposed as tools).
class ClaudeBrain implements Brain {
  ClaudeBrain({
    required this.apiKey,
    required this.registry,
    this.model = 'claude-sonnet-5-5',
  });

  final String apiKey;
  final SkillRegistry registry;
  final String model;
  final List<Map<String, dynamic>> _messages = [];

  @override
  Future<String> reply(String userText) async {
    _messages.add({'role': 'user', 'content': userText});

    for (var turn = 0; turn < 6; turn++) {
      final res = await http.post(
        Uri.parse('https://api.anthropic.com/v1/messages'),
        headers: {
          'x-api-key': apiKey,
          'anthropic-version': '2023-06-01',
          'content-type': 'application/json',
        },
        body: jsonEncode({
          'model': model,
          'max_tokens': 1024,
          'system': _system,
          'tools': registry.claudeTools(),
          'messages': _messages,
        }),
      );
      if (res.statusCode != 200) {
        throw Exception('Claude API ${res.statusCode}: ${res.body}');
      }

      final data = jsonDecode(utf8.decode(res.bodyBytes)) as Map<String, dynamic>;
      final content = (data['content'] as List).cast<Map<String, dynamic>>();
      _messages.add({'role': 'assistant', 'content': content});

      if (data['stop_reason'] != 'tool_use') {
        return content
            .where((b) => b['type'] == 'text')
            .map((b) => b['text'] as String)
            .join('\n');
      }

      // Run every tool the model asked for, then send results back.
      final results = <Map<String, dynamic>>[];
      for (final block in content.where((b) => b['type'] == 'tool_use')) {
        final out = await registry.call(
          block['name'] as String,
          Map<String, dynamic>.from(block['input'] as Map),
        );
        results.add({
          'type': 'tool_result',
          'tool_use_id': block['id'],
          'content': out,
        });
      }
      _messages.add({'role': 'user', 'content': results});
    }
    return 'Sorry, I could not finish that request.';
  }
}

/// Offline brain: simple rules, no internet needed.
/// Replace/extend `tryHandle` with an on-device LLM later
/// (e.g. a llama.cpp or MediaPipe LLM Flutter plugin).
class LocalBrain implements Brain {
  LocalBrain(this.registry);
  final SkillRegistry registry;

  /// Returns null when the rules can't handle the text.
  Future<String?> tryHandle(String text) async {
    final t = text.trim();

    final remind = RegExp(r'remind me in (\d+) min\w* to (.+)', caseSensitive: false)
        .firstMatch(t);
    if (remind != null) {
      return registry.call('reminder', {
        'title': remind.group(2),
        'minutes_from_now': int.parse(remind.group(1)!),
      });
    }

    final note = RegExp(r'^(?:note|save note)[: ]+(.+)', caseSensitive: false)
        .firstMatch(t);
    if (note != null) {
      return registry.call('notes', {'action': 'add', 'text': note.group(1)});
    }

    final mem = RegExp(r'^remember (\w+) (?:is|=) (.+)', caseSensitive: false)
        .firstMatch(t);
    if (mem != null) {
      return registry.call('memory',
          {'action': 'save', 'key': mem.group(1), 'value': mem.group(2)});
    }
    return null;
  }

  @override
  Future<String> reply(String userText) async =>
      await tryHandle(userText) ??
      'I am offline and cannot understand that yet. '
          'Try: "note: ...", "remind me in 5 minutes to ...", "remember X is Y".';
}

/// Offline AI: a small LLM running on the phone. Skills are used through a
/// simple text protocol (works with any model, no native tool calling needed):
/// the model writes a line `ACTION: {"skill":"notes","args":{...}}`.
class OnDeviceBrain implements Brain {
  OnDeviceBrain({required this.llm, required this.registry});
  final OnDeviceLlm llm;
  final SkillRegistry registry;

  String get _instructions => '''
You are a friendly personal assistant on a phone. Reply in the user's language
(Bengali, Hindi or English). Keep replies short.
You can use skills. To use one, end your reply with ONE line exactly like:
ACTION: {"skill":"<name>","args":{...}}
Only use a skill when the user clearly wants it. Available skills:
${registry.describe()}
''';

  @override
  Future<String> reply(String userText) async {
    final raw = await llm.ask(userText, instructions: _instructions);
    final m = RegExp(r'ACTION:\s*(\{.*\})', dotAll: true).firstMatch(raw);
    if (m == null) return raw;

    final spoken = raw.substring(0, m.start).trim();
    try {
      final call = jsonDecode(m.group(1)!) as Map<String, dynamic>;
      final result = await registry.call(
        call['skill'] as String,
        Map<String, dynamic>.from((call['args'] ?? {}) as Map),
      );
      return spoken.isEmpty ? result : '$spoken\n$result';
    } catch (_) {
      return spoken.isEmpty ? raw : spoken;
    }
  }
}

/// Order: 1) instant offline rules  2) on-device AI  3) Claude (only if an
/// API key was added)  4) help message.
class HybridBrain implements Brain {
  HybridBrain({required this.local, this.onDevice, this.cloud});
  final LocalBrain local;
  final OnDeviceBrain? onDevice;
  final ClaudeBrain? cloud;

  @override
  Future<String> reply(String userText) async {
    final quick = await local.tryHandle(userText);
    if (quick != null) return quick;

    if (onDevice != null && onDevice!.llm.isLoaded) {
      try {
        return await onDevice!.reply(userText);
      } catch (_) {/* fall through */}
    }
    if (cloud != null) {
      try {
        return await cloud!.reply(userText);
      } catch (_) {/* fall through */}
    }
    return local.reply(userText);
  }
}
