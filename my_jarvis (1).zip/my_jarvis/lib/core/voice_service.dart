import 'package:flutter_tts/flutter_tts.dart';
import 'package:speech_to_text/speech_to_text.dart';

/// Speech-to-text (mic) and text-to-speech (voice reply).
class VoiceService {
  final _stt = SpeechToText();
  final _tts = FlutterTts();
  var _available = false;

  /// Change to 'en_US' / 'hi_IN' as needed.
  String localeId = 'bn_BD';

  Future<void> init() async {
    _available = await _stt.initialize();
    await _tts.setLanguage(localeId.replaceAll('_', '-'));
    await _tts.setSpeechRate(0.5);
  }

  bool get isListening => _stt.isListening;

  Future<void> listen(void Function(String text, bool isFinal) onResult) async {
    if (!_available) return;
    await _stt.listen(
      localeId: localeId,
      onResult: (r) => onResult(r.recognizedWords, r.finalResult),
    );
  }

  Future<void> stopListening() => _stt.stop();

  Future<void> speak(String text) => _tts.speak(text);
}
