import 'skill.dart';

class SkillRegistry {
  final Map<String, Skill> _skills = {};

  void register(Skill skill) => _skills[skill.name] = skill;

  /// Plain-text skill list for models without native tool calling.
  String describe() => _skills.values
      .map((s) => '- ${s.name}: ${s.description} '
          'Arguments (JSON schema): ${s.inputSchema['properties']}')
      .join('\n');

  List<Map<String, dynamic>> claudeTools() =>
      _skills.values.map((s) => s.toClaudeTool()).toList();

  Future<String> call(String name, Map<String, dynamic> args) async {
    final skill = _skills[name];
    if (skill == null) return 'Unknown skill: $name';
    try {
      return await skill.run(args);
    } catch (e) {
      return 'Skill "$name" failed: $e';
    }
  }
}
