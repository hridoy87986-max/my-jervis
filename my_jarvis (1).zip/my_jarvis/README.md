# My Jarvis — local-first personal AI (Flutter)

Skills: memory, notes, reminders, voice (Bengali by default), chat.
Brain (all offline-capable): 1) instant rule commands, 2) a small AI model running fully on the phone (Gemma 4 E2B via `flutter_edge_ai`), 3) Claude only if you optionally add an API key.

## Setup

1. Install Flutter: https://docs.flutter.dev/get-started/install
2. Create the platform folders inside this project (one time):

       cd my_jarvis
       flutter create . --project-name my_jarvis --platforms android,ios

   (This keeps the existing `lib/` and `pubspec.yaml`.)
3. `flutter pub get`
4. Add permissions.

   **android/app/src/main/AndroidManifest.xml** (inside `<manifest>`):

       <uses-permission android:name="android.permission.INTERNET"/>
       <uses-permission android:name="android.permission.RECORD_AUDIO"/>
       <uses-permission android:name="android.permission.POST_NOTIFICATIONS"/>
       <queries>
         <intent><action android:name="android.speech.RecognitionService"/></intent>
       </queries>

   In `android/app/build.gradle`: set `minSdkVersion 30` (required by the on-device model engine; the model runs on arm64 phones only, i.e. almost all phones from the last ~6 years) and enable
   core library desugaring as required by flutter_local_notifications
   (see that package's README).

   **ios/Runner/Info.plist**:

       <key>NSMicrophoneUsageDescription</key><string>Voice commands</string>
       <key>NSSpeechRecognitionUsageDescription</key><string>Voice commands</string>

5. Run: `flutter run`
6. **Offline AI (one-time):** tap the download icon (top bar) while on Wi-Fi. The model is
   large (a few GB). After it finishes, the app works with no internet. Needs a phone with
   roughly 6 GB+ RAM for smooth use.
7. (Optional) Tap the key icon and paste your Claude API key (optional, only if you also want cloud answers; stored in secure storage).

## Offline commands (no API key needed)

- `note: buy milk`
- `remind me in 10 minutes to call mom`
- `remember wifi is abc123`

## Add a new skill

1. Create `lib/skills/my_skill.dart` extending `Skill` (name, description, inputSchema, run).
2. Register it in `main.dart`: `_registry.register(MySkill());`

Claude automatically sees it as a tool and decides when to call it.

## Notes

- Code was written but not compiled in this sandbox (no Flutter SDK). Expect to fix small
  package-version issues on first build.
- For a public app, do not ship users an embedded API key; route calls through your own server.
- The model call code in `lib/core/on_device_llm.dart` follows the `flutter_edge_ai` 2.6 README
  (docs: https://flutteredge.ai). If a later version changes names, only that file needs edits.
- Small on-device models follow skill instructions less reliably than Claude; the rule commands
  above are the dependable path for notes/reminders/memory.
- Skills use a simple `ACTION: {json}` text protocol, so any model works without native tool calling.
